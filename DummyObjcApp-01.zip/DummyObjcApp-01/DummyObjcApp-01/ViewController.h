//
//  ViewController.h
//  DummyObjcApp-01
//
//  Created by 海鮮ドン on 2022/02/12.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

