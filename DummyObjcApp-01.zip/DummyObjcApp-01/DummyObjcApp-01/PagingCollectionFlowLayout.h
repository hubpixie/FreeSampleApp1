#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PagingCollectionFlowLayout : UICollectionViewFlowLayout
@property (nonatomic, assign) CGFloat velocityThresholdPerPage;
@property (nonatomic, assign) CGFloat numberOfItemsPerPage;
@end

NS_ASSUME_NONNULL_END
