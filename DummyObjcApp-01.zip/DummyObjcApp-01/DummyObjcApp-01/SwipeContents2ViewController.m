#import "SwipeContents2ViewController.h"

@interface SwipeContents2ViewController () <UICollectionViewDataSource, UICollectionViewDelegate, UIScrollViewDelegate>
@property (nonatomic, assign)  CGFloat cellWidth;
@property (nonatomic, assign)  CGFloat sectionSpacing;
@property (nonatomic, assign)  CGFloat cellSpacing;
//@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

@property (nonatomic, strong) UICollectionView *collectionView;

@property (nonatomic, strong) NSArray *dataList;
@end

@implementation SwipeContents2ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self prepareData];
    [self setupUI];

}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

#pragma mark - CollectionView Data Source
- (NSInteger)collectionView:(UICollectionView *)collectionView
     numberOfItemsInSection:(NSInteger)section {
    return _dataList.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    UICollectionViewCell *cell = [_collectionView dequeueReusableCellWithReuseIdentifier:@"cell_id" forIndexPath:indexPath];

    UIColor *color = _dataList[indexPath.item];
    cell.backgroundColor = color;
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView
                  layout:(UICollectionViewLayout *)collectionViewLayout
  sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    return collectionView.frame.size;
}

- (void)scrollViewDidEndDecelerating:(UIScrollView*)scrollView {
    
    NSInteger pageIdx = floor(_collectionView.contentOffset.x / _collectionView.frame.size.width);
    NSLog(@"pageIdx = %ld", pageIdx);
}
/*
 // determine the index of the new page
 let pageWidth = collectionView.frame.size.width
 let index:Int = Int(collectionView.contentOffset.x / pageWidth)    // get sample content
 let currentSampleContent = arraySampleContent[index]
 let stringImageName = currentSampleContent["image_name"]!
 let imageTo = UIImage(named: stringImageName)    // transition animation for new background image
 UIView.transition(with: imageViewBackground, duration: 0.8, options: .transitionCrossDissolve, animations: {        // set image to imageView
     self.imageViewBackground.image = imageTo    }, completion: nil)
 */
#pragma mark - Privaste properties

- (UICollectionView*)collectionView {
    UICollectionViewFlowLayout *pageLayout = [UICollectionViewFlowLayout new];
    pageLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    pageLayout.sectionInset = UIEdgeInsetsMake(0, _sectionSpacing, 0, _sectionSpacing);
    pageLayout.itemSize = CGSizeMake(_cellWidth, _cellWidth);
    pageLayout.minimumLineSpacing = _cellSpacing;
    
    UICollectionView *selfView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:pageLayout];
    selfView.translatesAutoresizingMaskIntoConstraints = NO;
    selfView.showsHorizontalScrollIndicator = NO;
    selfView.backgroundColor = UIColor.whiteColor;
    selfView.decelerationRate = UIScrollViewDecelerationRateFast;
    selfView.prefetchingEnabled = YES;
    selfView.dataSource = self;
    selfView.delegate = self;
    return selfView;
}


#pragma mark - Privaste methods

- (void)prepareData {
    // calcute cellWidth, sectionSpacing, cellSpacing
    self.cellWidth = (9.0/9.0) * UIScreen.mainScreen.bounds.size.width;
    self.sectionSpacing = (0.0/9.0) * UIScreen.mainScreen.bounds.size.width;
    self.cellSpacing = (0.0/9.0) * UIScreen.mainScreen.bounds.size.width;
    
    // set test data
    self.dataList = @[
        UIColor.redColor,
        UIColor.greenColor,
        UIColor.blueColor,
        UIColor.purpleColor,
        UIColor.orangeColor,
        UIColor.blueColor,
        UIColor.cyanColor,
        UIColor.grayColor,
        UIColor.separatorColor
    ];

}

- (void)setupUI {
    self.view.backgroundColor = UIColor.whiteColor;
    _collectionView = [self collectionView];
    [_collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"cell_id"];
    [self.view addSubview:_collectionView];

    [[_collectionView .centerYAnchor
      constraintEqualToAnchor:self.view.centerYAnchor] setActive:YES];
    [[_collectionView .leadingAnchor
      constraintEqualToAnchor:self.view.leadingAnchor] setActive:YES];
    [[_collectionView .trailingAnchor
      constraintEqualToAnchor:self.view.trailingAnchor] setActive:YES];
    [[_collectionView .heightAnchor
      constraintEqualToConstant:_cellWidth] setActive:YES];
}

@end

/*
 https://medium.com/@qbo/swipe-content-with-subtle-transition-ae9d440ca918
 https://gist.github.com/gyubokbaik/60dcc9fc8857d5a152884d569579f1cd
 */
