//
//  SceneDelegate.h
//  DummyObjcApp-01
//
//  Created by 海鮮ドン on 2022/02/12.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

