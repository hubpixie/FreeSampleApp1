//
//  SwipeContentsViewController.h
//  DummyObjcApp-01
//
//  Created by 海鮮ドン on 2022/05/14.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SwipeContentsViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
