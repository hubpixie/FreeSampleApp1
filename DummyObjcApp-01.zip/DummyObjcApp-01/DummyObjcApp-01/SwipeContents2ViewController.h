//
//  SwipeContents2ViewController.h
//  DummyObjcApp-01
//
//  Created by 海鮮ドン on 2022/05/15.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SwipeContents2ViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
