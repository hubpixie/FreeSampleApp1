#import "PagingCollectionFlowLayout.h"

@implementation PagingCollectionFlowLayout

-(CGPoint)targetContentOffsetForProposedContentOffset:(CGPoint)proposedContentOffset
                                withScrollingVelocity:(CGPoint)velocity {
    if (!self.collectionView) {
        return proposedContentOffset;
    }
    CGFloat pageLength;
    CGFloat approxPage;
    CGFloat currentPage;
    CGFloat speed = 0;
    CGFloat nextPage = 0;
    
    // pageLength, approxPage, speed
    if (self.scrollDirection == UICollectionViewScrollDirectionHorizontal) {
        pageLength = (self.itemSize.width + self.minimumLineSpacing) * self.numberOfItemsPerPage;
        approxPage = self.collectionView.contentOffset.x / pageLength;
        speed = velocity.x;
    } else {
        pageLength = (self.itemSize.height + self.minimumLineSpacing) * self.numberOfItemsPerPage;
        approxPage = self.collectionView.contentOffset.y / pageLength;
        speed = velocity.y;
    }
    
    // set currentPage
    if (speed < 0) {
        currentPage = ceil(approxPage);
    }
    else if (speed > 0) {
        currentPage = floor(approxPage);
    }
    else {
        currentPage = round(approxPage);
    }
//    if (currentPage == INFINITY) {
//        currentPage = 1;
//    }
    
    // return value block
    CGPoint (^retPoint)(CGFloat) = ^(CGFloat page){
        if (self.scrollDirection == UICollectionViewScrollDirectionHorizontal) {
            return CGPointMake(page * pageLength, 0);
        } else {
            return CGPointMake(0, page * pageLength);
        }
    };
    
    if (speed == 0) {
        return retPoint(currentPage);
    }
    
    // set nextPage
    nextPage = currentPage + (speed > 0 ? 1 : -1);
    CGFloat inc = speed / self.velocityThresholdPerPage;
    nextPage += speed < 0 ? ceil(inc) : floor(inc);
    
    // return value to end
    return retPoint(nextPage);
}
@end
