import Foundation
import Promises
import Alamofire

struct DummyApi {
    static let apiClient = ApiClient()
    
    static func getTodos() -> Promise<(ResponseItem<[Todo]>)> {
        let promise = Promise<(ResponseItem<[Todo]>)>.pending()

        apiClient.request(RequestItem(endpoint: ApiEndpoint.getTodos,
                                     method: .get,
                                     parameter: EmptyParameter(),
                                     responseFormat: .json)) { (response: ResponseItem<[Todo]>?, error: Error?) in
            if let error = error {
                promise.reject(error)
            } else {
                if let data = response {
                    promise.fulfill((data))
                }
            }
        }
        return promise
    }
    
    static func findBy(parameter: SearchTodoParameter) -> Promise<ResponseItem<Todo>> {
        let promise = Promise<(ResponseItem<Todo>)>.pending()

        apiClient.request(RequestItem(endpoint: ApiEndpoint.getTodo,
                                     method: .get,
                                     parameter: parameter,
                                     responseFormat: .json)) { (response: ResponseItem<[Todo]>?, error: Error?) in
            if let error = error {
                promise.reject(error)
            } else {
                if let data = response {
                   let ret: ResponseItem<Todo> = ResponseItem<Todo>(stat: data.stat, code: data.code, message: data.message, response: data.response[0])
                    promise.fulfill(ret)
                }
            }
        }
        return promise
    }

}
