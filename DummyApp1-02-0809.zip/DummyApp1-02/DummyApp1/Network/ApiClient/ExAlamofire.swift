import Foundation
import Alamofire
import Promises

enum ErrorType {
    case other
    case unknown
    case network
    
    var code: Int {
        switch self {
        case .other:
            return 900
        case .unknown:
            return 901
        case .network:
            return 902
        }
    }
    var domain: String {
        return "UserDomain"
    }
}


extension Alamofire.DataRequest {
    /// Adds a handler to be called once the request has finished.
    func response(queue: DispatchQueue? = nil) -> Promise<(URLRequest, HTTPURLResponse, Data)> {
        return Promise { fulfill, reject in
            self.response(queue: queue) { rsp in
                if let error = rsp.error {
                    reject(error)
                } else if let req = rsp.request, let res = rsp.response, let data = rsp.data {
                    fulfill((req, res, data))
                } else {
                    reject(NSError(domain: ErrorType.other.domain, code: ErrorType.other.code, userInfo: nil))
                }
            }
        }
    }

    /// Adds a handler to be called once the request has finished.
    func responseData(queue: DispatchQueue? = nil) -> Promise<(data: Data, response: BaseDataResponse)> {
        return Promise { fulfill, reject in
            self.responseData(queue: queue) { response in
                switch response.result {
                case .success(let value):
                    fulfill((value, BaseDataResponse(response)))
                case .failure(let error):
                    reject(error)
                }
            }
        }
    }

    /// Adds a handler to be called once the request has finished.
    func responseString(queue: DispatchQueue? = nil) -> Promise<(string: String, response: BaseDataResponse)> {
        return Promise { fulfill, reject in
            self.responseString(queue: queue) { response in
                switch response.result {
                case .success(let value):
                    fulfill((value, BaseDataResponse(response)))
                case .failure(let error):
                    reject(error)
                }
            }
        }
    }

    /// Adds a handler to be called once the request has finished.
    func responseJSON(queue: DispatchQueue? = nil, options: JSONSerialization.ReadingOptions = .allowFragments) -> Promise<(json: Any, response: BaseDataResponse)> {
        return Promise { fulfill, reject in
            self.responseJSON(queue: queue, options: options) { response in
                switch response.result {
                case .success(let value):
                    fulfill((value, BaseDataResponse(response)))
                case .failure(let error):
                    reject(error)
                }
            }
        }
    }

    /// Adds a handler to be called once the request has finished.
    func responsePropertyList(queue: DispatchQueue? = nil, options: PropertyListSerialization.ReadOptions = PropertyListSerialization.ReadOptions()) -> Promise<(plist: Any, response: BaseDataResponse)> {
        return Promise { fulfill, reject in
            self.responsePropertyList(queue: queue, options: options) { response in
                switch response.result {
                case .success(let value):
                    fulfill((value, BaseDataResponse(response)))
                case .failure(let error):
                    reject(error)
                }
            }
        }
    }

    func responseDecodable<T: Decodable>(queue: DispatchQueue? = nil, decoder: JSONDecoder = JSONDecoder()) -> Promise<T> {
        return Promise { fulfill, reject in
            self.responseData(queue: queue) { response in
                switch response.result {
                case .success(let value):
                    do {
                        fulfill(try decoder.decode(T.self, from: value))
                    } catch {
                        reject(error)
                    }
                case .failure(let error):
                    reject(error)
                }
            }
        }
    }
 
    func responseDecodable<T: Decodable>(_ type: T.Type, queue: DispatchQueue? = nil, decoder: JSONDecoder = JSONDecoder()) -> Promise<T> {
        return Promise { fulfill, reject in
            self.responseData(queue: queue) { response in
                switch response.result {
                case .success(let value):
                    do {
                        fulfill(try decoder.decode(type, from: value))
                    } catch {
                        reject(error)
                    }
                case .failure(let error):
                    reject(error)
                }
            }
        }
    }
}

extension Alamofire.DownloadRequest {
    func response( queue: DispatchQueue? = nil) -> Promise<DefaultDownloadResponse> {
        return Promise { fulfill, reject in
            self.response(queue: queue) { response in
                if let error = response.error {
                    reject(error)
                } else {
                    fulfill(response)
                }
            }
        }
    }

    /// Adds a handler to be called once the request has finished.
    func responseData(queue: DispatchQueue? = nil) -> Promise<DownloadResponse<Data>> {
        return Promise { fulfill, reject in
            self.responseData(queue: queue) { response in
                switch response.result {
                case .success:
                    fulfill(response)
                case .failure(let error):
                    reject(error)
                }
            }
        }
    }
}


/// Alamofire.DataResponse, but without the `result`, since the Promise represents the `Result`
struct BaseDataResponse {
    init<T>(_ rawrsp: Alamofire.DataResponse<T>) {
        request = rawrsp.request
        response = rawrsp.response
        data = rawrsp.data
        timeline = rawrsp.timeline
    }

    /// The URL request sent to the server.
    let request: URLRequest?

    /// The server's response to the URL request.
    let response: HTTPURLResponse?

    /// The data returned by the server.
    let data: Data?

    /// The timeline of the complete lifecycle of the request.
    let timeline: Timeline
}


