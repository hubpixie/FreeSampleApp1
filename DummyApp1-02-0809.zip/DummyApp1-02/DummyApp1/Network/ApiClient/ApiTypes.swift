//
//  ApiTypes.swift
//  DummyApp1
//
//  Created by 海鮮ドン on 2021/05/16.
//

import Foundation

typealias HttpStatusCode = Int
typealias ApiMethod = String

struct DataStat {
    let stat: HttpStatusCode
    let code: Int
    let message: String!
    let data: Any
    
    init(stat: HttpStatusCode,
        code: Int,
        message: String? = nil,
        data: Any) {
        self.stat = stat
        self.code = code
        self.message = message
        self.data = data
    }
}
