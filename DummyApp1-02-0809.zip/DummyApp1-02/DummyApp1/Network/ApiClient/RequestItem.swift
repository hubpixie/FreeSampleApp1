import Foundation
import Alamofire

struct RequestItem<RequestParameterT: RequestParameter> {
    // MARK: Properties
    let endpoint: ApiEndpoint
    let method: HTTPMethod
    let parameter: RequestParameterT
    let responseFormat: ResponseFormat
    let encoding: ParameterEncoding
    
    // MARK: Initializers
    init(endpoint: ApiEndpoint, method: HTTPMethod,
         parameter: RequestParameterT,
         responseFormat: ResponseFormat = .json,
         encoding: ParameterEncoding = URLEncoding.default) {
        self.endpoint = endpoint
        self.method = method
        self.parameter = parameter
        self.responseFormat = responseFormat
        self.encoding = encoding
    }
}
