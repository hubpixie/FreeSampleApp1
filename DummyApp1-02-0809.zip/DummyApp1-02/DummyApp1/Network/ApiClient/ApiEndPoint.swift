import Foundation
import Alamofire

// MARK: - Endpoint

enum ApiEndpoint {
    case getTodo
    case getTodos

    var absoluteString: String {
        return "\(ApiClient.basePath)/todos"
    }
    
    var url: URL {
        return URL(string: absoluteString)!
    }
    
    var methond: String {
        switch self {
        case .getTodo:
            return "getTodo"
        case .getTodos:
            return "getTodos"
        }
    }
}
