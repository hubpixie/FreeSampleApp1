import Foundation
import Alamofire
import Promises

enum ResponseFormat {
    case json
}

typealias CompleteHandler<ResponseType> = ((_ response: ResponseType?, _ error: Error?) -> Void)

class ApiClient {
    static var basePath = "http://httpbin.org"
    static var credential: URLCredential?
    static var customHeaders: [String:String] = [:]

    private var sessionManager: Alamofire.SessionManager
    private let jsonDecoder: JSONDecoder
    
    init() {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 30
        self.sessionManager = Alamofire.SessionManager(configuration: config)
        self.jsonDecoder = JSONDecoder()    }
    
    func get<ResponseType: Codable>(endpoint: ApiEndpoint,
                        responseFormat: ResponseFormat = .json
        , handler: CompleteHandler<ResponseItem<ResponseType>>? = nil){
        return request(RequestItem(endpoint: endpoint, method: .get, parameter: EmptyParameter(), responseFormat: responseFormat), handler: handler)
    }

    func get<ResponseType: Codable, RequestPrameterT: RequestParameter>(endpoint: ApiEndpoint,
                        parameter: RequestPrameterT,
                        responseFormat: ResponseFormat = .json,
                        handler: CompleteHandler<ResponseItem<ResponseType>>? = nil){
        return request(RequestItem(endpoint: endpoint,
                                   method: .get,
                                   parameter: parameter,
                                   responseFormat: responseFormat),
                       handler: handler)
    }
    
    func post<ResponseType: Codable>(endpoint: ApiEndpoint,
                        responseFormat: ResponseFormat = .json
        , handler: CompleteHandler<ResponseItem<ResponseType>>? = nil){
        return request(RequestItem(endpoint: endpoint, method: .get, parameter: EmptyParameter(), responseFormat: responseFormat), handler: handler)
    }

    func post<ResponseType: Codable, RequestPrameterT: RequestParameter>(endpoint: ApiEndpoint,
                        parameter: RequestPrameterT,
                        responseFormat: ResponseFormat = .json,
                        handler: CompleteHandler<ResponseItem<ResponseType>>? = nil){
        return request(RequestItem(endpoint: endpoint,
                                   method: .post,
                                   parameter: parameter,
                                   responseFormat: responseFormat),
                       handler: handler)
    }

    
    func request<ResponseType: Codable, RequestParameterT>(
        _ requestItem: RequestItem<RequestParameterT>,
        on queue: DispatchQueue? = nil,
        handler: CompleteHandler<ResponseItem<ResponseType>>? = nil) {
        
        Alamofire
            .request(requestItem.endpoint.url,
                     method: requestItem.method,
                     parameters: {
                        var params = requestItem.parameter.parameters
                        params[StandardParameterKeys.method.key] = requestItem.endpoint.methond
                        return params
                     }())
            .debugLog()
            .responseData(queue: queue ?? DispatchQueue.global()) {
                if let data = $0.data {
                    if let response: ResponseItem<ResponseType> = self.decodeResponse(responseFormat: requestItem.responseFormat, data: data) {
                        handler?(response, nil)
                    } else {
                        debugPrint("failure")
                        handler?(nil, NSError(domain: "ErrorType.other.domain", code: 999, userInfo: nil))
                    }
                } else {
                    handler?(nil, $0.error)
                }
            }
    }

    private func decodeResponse<ResponseType: Decodable>(responseFormat: ResponseFormat, data: Data) -> ResponseItem<ResponseType>? {
        do {
            switch responseFormat {
            case .json:
                let parsedResponse: ResponseItem<ResponseType> = try jsonDecoder.decode(ResponseItem<ResponseType>.self, from: data)
                return parsedResponse
            }
        } catch let error {
            debugPrint(error)
            return nil
        }
    }
    
    func uploadData(_ url: String, parameters:[String:Any], completion:@escaping(_:Any)->Void) {

        guard  let imageUrl: URL = parameters["imageUrl"] as? URL else {return}
        sessionManager
            .upload(multipartFormData: { multipartFormData in
                print("self == \(self == nil)")
                multipartFormData.append(imageUrl, withName: "fileData", fileName: "largeImage.png", mimeType: "image/png")
            }, to: url) {result in
                switch result {
                case .success(let upload, _, _):
                    upload
                        .uploadProgress(closure: { (progress) in
                            print(progress)
                    })

                    upload.responseData { response in
    //                        print(response.debugDescription)
                        if let JSON = response.result.value {
                            completion(JSON)
                        }else{
                            completion(())
                        }
                    }

                case .failure(let encodingError):
                    completion(())
                }
            }

    }


}

// MARK: - Request
fileprivate extension Request {
    func debugLog() -> Self {
        #if DEBUG
        //ebugPrint(debugDescription)
        
        #endif
        return self
        
    }
}
