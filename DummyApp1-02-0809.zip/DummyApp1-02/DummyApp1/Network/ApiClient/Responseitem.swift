import Foundation
import Alamofire

class ResponseItem<ItemType: Codable>: Decodable {
    // MARK: Properties
    //let statInfo: DataStat
    let stat: HttpStatusCode
    let code: Int
    let message: String!
    let response: ItemType

    var data: Any? = nil

    // MARK: Initializers
    init(stat: HttpStatusCode,
         code: Int,
         message: String,
         response: ItemType) {
        self.stat = stat
        self.code = code
        self.message = message
        self.response = response
    }
    
    required init(from decoder:Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        stat = try values.decode(HttpStatusCode.self, forKey: .stat)
        code = try values.decode(Int.self, forKey: .code)
        message = try values.decode(String.self, forKey: .message)
        response = try values.decode(ItemType.self, forKey: .response)
    }
    
    enum CodingKeys: String, CodingKey {
        case stat
        case code
        case message
        case response
    }
}
