import Foundation
import Alamofire

// MARK: - EmptyParameterKeys
protocol ParameterKey: Hashable {
    var key: String { get }
}

enum StandardParameterKeys: ParameterKey {
    case method
    case systemApp
    case cpAuoneToken
    case appid
    case calculationFlag
    
    // MARK: Internal Properties
    var key: String {
        switch self {
        case .method:
            return "method"
        case .systemApp:
            return "system_app"
        case .cpAuoneToken:
            return "cpAuoneToken"
        case .appid:
            return "appid"
        case .calculationFlag:
            return "calculation_flag"
        }
    }
}

// MARK: - RequestParameter
protocol RequestParameter {
    associatedtype T : ParameterKey
    
    // MARK: Internal Properties
    var parameters: Alamofire.Parameters { get }
    var standardParam: Alamofire.Parameters { get }

    // MARK: Private Properties
    var parameter: [Self.T: Any] { get set }
    
    // MARK: Internal Methods
    mutating func setParameter(_ key: Self.T, _ value: Any)
}

// MARK: - RequestParameter

extension RequestParameter {
    var standardParam: Alamofire.Parameters {
        let params: [StandardParameterKeys : Any] =
            [.systemApp: "systemApp", .cpAuoneToken: "cpAuoneToken",
                                                     .appid: "appid", .calculationFlag: "calculationFlag"]
        return params.transform { (param, any) in
            return (param.key, any)
        }
    }
    
    var parameters: Alamofire.Parameters {
        if parameter.isEmpty {
            return standardParam
        }

        var params = parameter.transform { (param, any) in
            return (param.key, any)
        }
        params = params.merging(standardParam) {(item1, item2) in item1}
        return params
    }

    mutating func setParameter(_ key: Self.T, _ value: Any) {
        parameter[key] = value
    }
}

// MARK: - EmptyParameter

enum EmptyParameterKeys: ParameterKey {
    case empty
    
    // MARK: Internal Properties
    var key: String {
        return ""
    }
}

struct EmptyParameter: RequestParameter {
    typealias T = EmptyParameterKeys
    var parameter: [EmptyParameterKeys : Any] = [:]
    init() {}
}

// MARK: - StandardParameter


// MARK: - Private extension

private extension Dictionary {
    // MARK: Methods
    func transform<NKey, NValue>(transformer: @escaping ((Key, Value) -> (NKey, NValue))) -> Dictionary<NKey, NValue> {
        var dic: [NKey: NValue] = [:]
        forEach {
            let pair = transformer($0.key, $0.value)
            dic[pair.0] = pair.1
        }
        return dic
    }
    
    static func += (left: inout [Key: Value], right: [Key: Value]) {
        for (key, value) in right {
            left[key] = value
        }
    }
}
