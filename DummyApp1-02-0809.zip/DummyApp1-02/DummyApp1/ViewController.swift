//
//  ViewController.swift
//  DummyApp1
//
//  Created by 海鮮ドン on 2021/04/29.
//

import UIKit
import Promises

class ViewController: UIViewController {
    let apiClient = ApiClient()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
//        self.execGetTodos()
//        self.execFindTodoBy()
        
        //execUploadData()
        fetchMediaTargets() { data in
            print("mediaData count = \(data.count)")
        }
        
    return
        let promise1 = Promise<String> {fullfill, reject in
            DispatchQueue.main.asyncAfter(deadline: .now() + 10) {
                fullfill("123")
            }
        }
        
        Promise(on: .global()) { fulfill, reject in
            var stop = false
            for i in 1...2 {
                promise1
                    .then { value in
//                        if stop {
//                            reject(NSError())
//                            return}
                        print("i = \(i)")
//                        if value == "123" {
//                            stop = true
//                            return
//                        }
                        if i == 2 {
                            fulfill(())
                        }
                    }
            }

        }
        .then {
            print("SUCCESED")
        }
        .catch { error in
            print(error.localizedDescription)
        }
    }

    func execGetTodos()  {
        DummyApi.getTodos().then { data in
            print(data)
        }
        .catch { error in
           print(error)
        }
    }

    func execFindTodoBy()  {
        var parameter: SearchTodoParameter = SearchTodoParameter()
        parameter.setParameter(.order, 1)
        DummyApi.findBy(parameter: parameter).then { data in
            print(data)
        }.catch { error in
           print(error)
        }
    }

    func execUploadData() {
        let acl =  ApiClient()
        DispatchQueue.main.async { [weak self] in
            guard let self = self else {return}
            var params: [String: Any] = [:]
            params["aaa"] = "111".data(using: .utf8)
            params["bbb"] = "bbb".data(using: .utf8)
            params["ccc"] = self.date2Data(date: Date())
    //        params["image"] = UIImage(named: "largeImage")
            params["imageUrl"] = Self.createLocalUrl(forImageNamed: "largeImage")

            acl.uploadData("https://httpbin.org/post", parameters: params) { (res) in
                print("res == \(res)")
            }
        }
    }
    
    func date2Data(date: Date) -> Data?{
        let cal = Calendar(identifier: .gregorian)
        var comp = cal.dateComponents([.day,.month,.year,.hour,.minute,.second], from: date)
        var year = comp.year
        let yearData:Data = Data(bytes: &year, count: MemoryLayout.size(ofValue: year))
        let year1:Data = yearData.subdata(in: 0..<1)
        let year2:Data = yearData.subdata(in: 1..<2)
        let settingArray = [UInt8]([
              UInt8(year1[0])
            , UInt8(year2[0])
            , UInt8(comp.month!)
            , UInt8(comp.day!)
            , UInt8(comp.hour!)
            , UInt8(comp.minute!)
            , UInt8(comp.second!)
        ])
        return  Data(bytes: settingArray, count: MemoryLayout.size(ofValue: settingArray))
        
    }
    
    static func createLocalUrl(forImageNamed name: String) -> URL? {

        let fileManager = FileManager.default
        let cacheDirectory = fileManager.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        let url = cacheDirectory.appendingPathComponent("\(name).png")

        guard fileManager.fileExists(atPath: url.path) else {
            guard
                let image = UIImage(named: name),
                let data = image.pngData()
            else { return nil }

            fileManager.createFile(atPath: url.path, contents: data, attributes: nil)
            return url
        }

        return url
    }
    
    /*
    private func fetchMediaTargets() -> [MediaHashData] {
        let retData = try? await(Promise<[MediaHashData]>(on: .global(qos: .userInteractive)){ fulfill, _ in
            let mediaGen = MediaHashGen()
            mediaGen.fetchMediaTargets(mediaTypes: [.image, .video]) { data in
                fulfill((data))
            }
        })
        return retData ?? []
    }
     */
    private func fetchMediaTargets(handler: (([MediaHashData]) -> Void)?){
        let retData = try? await(Promise<[MediaHashData]>(on: .global(qos: .userInteractive)){ fulfill, _ in
            let mediaGen = MediaHashGen()
            mediaGen.fetchMediaTargets(mediaTypes: [.image, .video]) { data in
                handler?((data))
            }
        })
    }

}

