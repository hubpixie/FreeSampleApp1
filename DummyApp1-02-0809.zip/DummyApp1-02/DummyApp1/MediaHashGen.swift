
import Foundation
import Photos


struct MediaHashData {
    let mediaType: PHAssetMediaType
    let url: URL?
    let hash: String?
}

class MediaHashGen {
    private let kQueueLimit: Int = 4
    private let lock: NSLock = NSLock()
    func fetchMediaTargets(mediaTypes: [PHAssetMediaType], completeHandler: (([MediaHashData] ) -> Void)?) {
        let mediaAssets = {() -> [PHAsset] in
            var retAssets: [PHAsset] = []
            let collections = PHAssetCollection.fetchAssetCollections(
                with: .smartAlbum,
                subtype: .any,
                options: PHFetchOptions())
            for idx in 0..<collections.count {
                let phAssets = PHAsset.fetchAssets(in: collections[idx], options: nil)
                for assetIdx in 0..<phAssets.count {
                    let phAsset = phAssets[assetIdx]
                    if mediaTypes.contains(phAsset.mediaType) {
                        retAssets.append(phAssets[assetIdx])
                    }
                }
            }
            return retAssets
        }()
        
        if mediaAssets.isEmpty {
            completeHandler?([])
            return
        }
        var fetchedData: [MediaHashData] = []
        for _ in 0..<kQueueLimit {
            var queryIndex = 0
            var usingIdex = 0
            while queryIndex < mediaAssets.count {
                let phAsset = mediaAssets[queryIndex]
                if usingIdex >= kQueueLimit {
                    Thread.sleep(forTimeInterval: 0.01)
                    continue
                }
                
                let keepingIdex = queryIndex
                usingIdex += 1
                if phAsset.mediaType == .image {
                    let options = PHContentEditingInputRequestOptions()
                    options.canHandleAdjustmentData = {(adjustmeta: PHAdjustmentData) -> Bool in
                        return true
                    }
                    phAsset.requestContentEditingInput(with: options) { contentEdit, _ in
                        usingIdex -= 1
                        let mediaData = MediaHashData(mediaType: .image,
                                                     url: contentEdit?.fullSizeImageURL,
                                                     hash: "\(contentEdit?.hash ?? 0)")
//
                        fetchedData.append(mediaData)
                        if keepingIdex >= mediaAssets.count - 1 {
                            completeHandler?(fetchedData)
                        }
                    }
                } else if phAsset.mediaType == .video {
                    PHImageManager.default().requestAVAsset(forVideo: mediaAssets[queryIndex], options: PHVideoRequestOptions()) { avAsset, _, _ in
                        usingIdex -= 1
                        if let avUrl = avAsset as? AVURLAsset {
                            let mediaData = MediaHashData(mediaType: .video,
                                                          url: avUrl.url,
                                                          hash: "\(avUrl.hash)")
                            fetchedData.append(mediaData)
                        }
                        if keepingIdex >= mediaAssets.count - 1 {
                            completeHandler?(fetchedData)
                        }
                    }
                }
                lock.lock()
                queryIndex += 1
                lock.unlock()
            }
        }
    }
}
