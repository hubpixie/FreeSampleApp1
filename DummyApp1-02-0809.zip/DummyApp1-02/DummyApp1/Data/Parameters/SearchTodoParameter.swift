
import Foundation


// MARK: - NoneParameterKeys
enum SearchTodoParameterKeys: ParameterKey {
    case title
    case order
    case date

    // MARK: Internal Properties
    var key: String {
        switch self {
        case .title:
            return "title"
        case .order:
            return "order"
        case .date:
            return "data"
        }
    }
}

// MARK: - NoneParameter
struct SearchTodoParameter: RequestParameter {
    typealias T = SearchTodoParameterKeys
    var parameter: [SearchTodoParameterKeys : Any] = [:]
}
