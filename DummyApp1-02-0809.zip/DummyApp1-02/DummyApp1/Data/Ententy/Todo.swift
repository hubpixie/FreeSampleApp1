import Foundation

struct Todo: Codable {
    let id: Int
    let title: String
    let order: Int
    let completed: Bool
    let createdAt: String
}
